import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {

  logado = false;
  usuario = '';

  saldo = 1000;

  historico: any[] = [];

  mostrarModal = false;

  jogoSelecionado: any = null;

  timeSelecionado = '';
  probSelecionada = 0;
  oddSelecionada = 0;

  valorAposta = 0;

  golsAposta = {
    timeA: 0,
    timeB: 0
  };

  jogos = [
    { timeA: 'Brasil', timeB: 'Argentina', probA: 78, probB: 22, oddA: 1.25, oddB: 4.10, golsA: 2, golsB: 1, data: '28/06/2026', hora: '19:00' },
    { timeA: 'França', timeB: 'Alemanha', probA: 55, probB: 45, oddA: 2.10, oddB: 2.30, golsA: 1, golsB: 1, data: '30/06/2026', hora: '16:00' },
    { timeA: 'Portugal', timeB: 'Espanha', probA: 48, probB: 52, oddA: 2.40, oddB: 1.90, golsA: 1, golsB: 2, data: '05/07/2026', hora: '20:00' },
    { timeA: 'Inglaterra', timeB: 'Holanda', probA: 60, probB: 40, oddA: 1.80, oddB: 2.60, golsA: 2, golsB: 0, data: '12/07/2026', hora: '18:00' },
    { timeA: 'Itália', timeB: 'Uruguai', probA: 50, probB: 50, oddA: 2.00, oddB: 2.00, golsA: 1, golsB: 1, data: '15/07/2026', hora: '21:00' },
    { timeA: 'México', timeB: 'Estados Unidos', probA: 52, probB: 48, oddA: 1.95, oddB: 2.05, golsA: 2, golsB: 2, data: '18/07/2026', hora: '20:00' },
    { timeA: 'Japão', timeB: 'Coreia do Sul', probA: 46, probB: 54, oddA: 2.50, oddB: 1.85, golsA: 1, golsB: 2, data: '20/07/2026', hora: '19:00' },
    { timeA: 'Marrocos', timeB: 'Senegal', probA: 53, probB: 47, oddA: 1.90, oddB: 2.20, golsA: 1, golsB: 1, data: '22/07/2026', hora: '18:30' }
  ];

  entrar() {
    this.logado = true;
  }

  abrirAposta(jogo: any, time: string, prob: number, odd: number) {

    this.jogoSelecionado = jogo;
    this.timeSelecionado = time;
    this.probSelecionada = prob;
    this.oddSelecionada = odd;

    this.valorAposta = 0;

    this.golsAposta = {
      timeA: 0,
      timeB: 0
    };

    this.mostrarModal = true;
  }

  confirmarAposta() {

    if (this.valorAposta <= 0) {
      alert('Informe um valor válido!');
      return;
    }

    if (this.valorAposta > this.saldo) {
      alert('Saldo insuficiente!');
      return;
    }

    this.saldo -= this.valorAposta;

    const ganho = this.valorAposta * this.oddSelecionada;

    this.historico.unshift({
      time: this.timeSelecionado,
      valor: this.valorAposta,
      probabilidade: this.probSelecionada,
      odd: this.oddSelecionada,
      gols: this.golsAposta,
      ganhoPossivel: ganho,
      resultado: this.simularResultado(this.probSelecionada)
    });

    this.mostrarModal = false;
  }

  simularResultado(prob: number) {
    return Math.random() * 100 <= prob ? 'GANHOU' : 'PERDEU';
  }
}