const mongoose = require('mongoose');

const BetSchema = new mongoose.Schema({
    matchId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Match',
        required: true
    },
    selectedTeam: {
        type: String,
        required: true
    },
    value: {
        type: Number,
        required: true
    },
    odd: Number,
    probability: Number,
    goalsA: Number,
    goalsB: Number,
    result: {
        type: String,
        enum: ['GANHOU', 'PERDEU']
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('Bet', BetSchema);