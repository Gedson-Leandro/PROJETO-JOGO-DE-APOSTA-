const mongoose = require('mongoose');

const MatchSchema = new mongoose.Schema({
    timeA: {
        type: String,
        required: true
    },
    timeB: {
        type: String,
        required: true
    },
    probA: Number,
    probB: Number,
    oddA: Number,
    oddB: Number,
    golsA: Number,
    golsB: Number,
    data: String,
    hora: String
});

module.exports = mongoose.model('Match', MatchSchema);