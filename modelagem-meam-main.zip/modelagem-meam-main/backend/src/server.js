const express = require('express');
const cors = require('cors');

const connectDB = require('./config/database');
const matchRoutes = require('./routes/matchRoutes');

const app = express();

// conexão MongoDB
connectDB();

app.use(cors());
app.use(express.json());

// rotas
app.use('/api/matches', matchRoutes);

// teste API
app.get('/', (req, res) => {
    res.send('API Copa Apostas funcionando 🚀');
});

const PORT = 3001;

app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});