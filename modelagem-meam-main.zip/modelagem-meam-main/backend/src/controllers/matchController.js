const Match = require('../models/Match');

// GET ALL MATCHES DO MONGO
const getMatches = async (req, res) => {
    try {
        const matches = await Match.find();
        res.json(matches);
    } catch (error) {
        res.status(500).json({ error: 'Erro ao buscar jogos' });
    }
};

module.exports = {
    getMatches
};